import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './component.html'
})
export class AppComponent  { name = 'Angular 2 Operation'; }
